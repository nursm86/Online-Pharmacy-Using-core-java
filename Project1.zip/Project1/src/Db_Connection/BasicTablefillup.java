/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Db_Connection;

/**
 *
 * @author Nur_Islam
 */
public interface BasicTablefillup {
    public static void fillTable(){};
    public static void getValue(String username,String password){};
}
